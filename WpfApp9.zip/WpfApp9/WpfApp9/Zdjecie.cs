﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp9
{
    public class Zdjecie
    {
        public string source { get; set; }
        public int polubienia { get; set; }
        public int pobrania { get; set; }

        public Zdjecie(string source)
        {
            this.source = source;
            this.polubienia = 0;
            this.pobrania = 0;
        }
       public void dodajPolubienie()
        {
            polubienia++;
        }
        public void odlub()
        {
            polubienia--;
            if(polubienia <= 0)
            {
                polubienia = 0;
            }
        }
        public void pobierz()
        {
            pobrania++;
        }

    }
}
