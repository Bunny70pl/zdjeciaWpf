﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp9
{
    /// <summary>
    /// Logika interakcji dla klasy Karuzela.xaml
    /// </summary>
    public partial class Karuzela : Window
    {
        int i { get; set; }
        List<Zdjecie> lista = new List<Zdjecie>();
        string tekstLinku = "http://www.gravatar.com/avatar/ccac9a107581b343e832a2b040278b98?s=128&d=identicon&r=PG";
        public Karuzela()
        {
            InitializeComponent();
            Zdjecie zdj1 = new Zdjecie("rys1.jpg");
            Zdjecie zdj2 = new Zdjecie("rys2.jpg");
            Zdjecie zdj3 = new Zdjecie("rys3.jpg");
            Zdjecie zdj4 = new Zdjecie("rys4.jpg");
            lista.Add(zdj1);
            lista.Add(zdj2);
            lista.Add(zdj3);
            lista.Add(zdj4);
            lista.Add(new Zdjecie(tekstLinku));
            tekstLinku = "https://cdn.pixabay.com/photo/2024/11/26/18/50/skyscraper-9226515_960_720.jpg";
            lista.Add(new Zdjecie(tekstLinku));
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            i--;
            if (i <= 0)
            {
                i = lista.Count - 1;
            }
            zdjecie2.Source = new BitmapImage(new Uri(lista[i].source, UriKind.RelativeOrAbsolute));
            textPolubienia.Text = "Polubienia: " + lista[i].polubienia;
            textPobrania.Text = "Pobrana: " + lista[i].pobrania;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            i++;
            if (i >= lista.Count)
            {
                i = 0;
            }
            zdjecie2.Source = new BitmapImage(new Uri(lista[i].source, UriKind.RelativeOrAbsolute));
            textPolubienia.Text = "Polubienia: " + lista[i].polubienia;
            textPobrania.Text = "Pobrana: " + lista[i].pobrania;
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            lista[i].dodajPolubienie();
            textPolubienia.Text = "Polubienia: " + lista[i].polubienia;
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {

            lista[i].odlub();
            textPolubienia.Text = "Polubienia: " + lista[i].polubienia;
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            lista[i].pobierz();
            textPobrania.Text = "Pobrana: " + lista[i].pobrania;
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            if (lista.Count > 1) {
                lista.Remove(lista[i]);
            }
        }

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            tekstLinku = linkUzytkownika.Text;
            lista.Add(new Zdjecie(tekstLinku));
        }
    }
}
