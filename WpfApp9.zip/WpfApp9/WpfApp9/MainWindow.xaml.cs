﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp9
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            zdjecie.Source = new BitmapImage(new Uri("rys2.jpg",UriKind.Relative));
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            List<string> list = new List<string>();
            list.Add("rys1.jpg");
            list.Add("rys2.jpg");
            list.Add("rys3.jpg");
            list.Add("rys4.jpg");
            Random random = new Random();
            int randomowa = random.Next(list.Count);
            zdjecie.Source = new BitmapImage(new Uri(list[randomowa], UriKind.Relative));
        }
    }
}
